---
name: html-page-builder
description: 根据用户一句话的网页需求,直接生成一个完整、可在浏览器打开的 HTML 页面,并在 HTML 上标注清晰的层级(包裹关系)与节点标记(section/component/icon/chart 等)。当用户说"做个落地页/登录页/定价页/数据页""设计一个 X 页面""帮我搭个 Y 的网页/UI",或任何要网页/页面/设计稿的需求时,使用本 skill。即使描述模糊也按常见模式补全并产出完整页面,不反问个不停,不只给片段。
---

# HTML Page Builder

产出:一份完整、自包含、可直接在浏览器打开的 HTML 文件,且每个有意义的节点都带标记、用嵌套表达包裹关系。
内部走"想清楚结构 → 照模板拼装 → 自检"三步,只把最终 HTML 给用户。

## 标记与层级约定(必须遵守)

这是本 skill 的核心。生成的 HTML 要让人(和程序)一眼看出"这是什么、它包在谁里面"。

**(1) 每个有意义的节点都加 data-node,值从下面这个闭集里选:**

| data-node | 含义 | 典型标签 |
|---|---|---|
| `section`   | 页面级区块 | section/header/footer |
| `container` | 纯布局容器(把若干子节点框在一起的 grid/flex 行或列) | div |
| `component` | 可复用的组合单元(卡片、KPI、价格档、导航条、按钮组、表单) | div/article/nav |
| `icon`      | 图标 | span/svg |
| `chart`     | 图表/可视化 | div/svg |
| `image`     | 图片/插画/媒体 | img/figure |
| `text`      | 重要文字块(标题或段落) | h1-h6/p |
| `button`    | 按钮或行动链接 | a/button |
| `input`     | 表单字段 | input/select/textarea |
| `list`      | 列表组 | ul/ol |
| `table`     | 数据表 | table |

**(2) 可选再加两个属性增强可读性:**
- `data-type`:具体子类,如 `hero`/`kpi-card`/`line-chart`/`primary`(按钮变体)。
- `data-name`:人类可读名字,如 `总访问量`、`本周访问趋势`。

**(3) 用嵌套表达包裹关系——这是"层级"的关键:**
不要把节点拍平铺开。谁包含谁,就把谁嵌进谁里面。标准的纵深是:
`section` → `container` → `component` → 叶子(`icon`/`text`/`button`/`image`/`chart`…)。
例如一张 KPI 卡(component)里包着一个标题(text)、一个数值(text)、一个图标(icon),就要真的嵌三层,而不是平级排开。这样后续程序只要遍历 DOM,就能还原整棵层级树。

## 第一步:想清楚结构(心里完成)

判定页面类型(landing/pricing/login/signup/dashboard/contact/generic)→ 按类型铺常见区块骨架 → 选基调(professional/minimal/playful/bold/elegant/technical)→ 定主色(没给用 #4F46E5)。
缺失信息按常见设计模式补默认,不反问;只有缺失项会彻底改变方向时,才在 HTML 顶部用 `<!-- 假设:... -->` 标一行,然后照常给完整页面。

常见骨架:
- landing:`nav → hero → feature-grid → testimonial → pricing-table → cta-band → footer`
- login:`nav → form → footer`
- dashboard:`nav → page-header → stats(KPI 卡组) → charts → table → footer`

## 第二步:照模板拼装(整页只用这一套设计系统)

### 页面外壳(每次都用)

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{页面标题}}</title>
<style>
:root{
  --brand:#4F46E5; --brand-hover:#4338CA; --on-brand:#fff;
  --surface:#fff; --surface-alt:#f8fafc; --fg:#0f172a; --muted:#64748b; --border:#e2e8f0;
  --radius:12px; --maxw:1120px;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;
  color:var(--fg);background:var(--surface);line-height:1.6}
.wrap{max-width:var(--maxw);margin:0 auto;padding:0 24px}
section,header,footer{padding:80px 0}
h1{font-size:clamp(2rem,5vw,3.5rem);line-height:1.1;font-weight:700}
h2{font-size:2rem;font-weight:700;margin-bottom:8px}
h3{font-size:1.125rem;font-weight:600}
p{color:var(--muted)}
.btn{display:inline-block;padding:12px 24px;border-radius:var(--radius);font-weight:600;
  text-decoration:none;cursor:pointer;border:none;font-size:1rem}
.btn-primary{background:var(--brand);color:var(--on-brand)}
.btn-primary:hover{background:var(--brand-hover)}
.btn-secondary{background:var(--surface);color:var(--fg);border:1px solid var(--border)}
.btn-ghost{background:transparent;color:var(--brand)}
.grid{display:grid;gap:24px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px}
.alt{background:var(--surface-alt)}
.center{text-align:center}
.muted{color:var(--muted)}
@media(max-width:768px){section,header,footer{padding:48px 0}}
</style>
</head>
<body>
  <!-- 按区块序列依次放组件,注意层层嵌套 -->
</body>
</html>
```

换主题只改 `:root`;颜色一律走变量,不写死。

### 组件写法(已含标记与嵌套,文案换成真实内容)

**hero(首屏,文左图右):**
```html
<section data-node="section" data-type="hero">
  <div class="wrap grid" data-node="container" style="grid-template-columns:1fr 1fr;align-items:center;gap:48px">
    <div data-node="container" data-name="文案区">
      <h1 data-node="text" data-type="heading">{{主标题}}</h1>
      <p data-node="text" style="font-size:1.25rem;margin:20px 0 32px">{{副标题}}</p>
      <div data-node="component" data-type="button-group" style="display:flex;gap:16px">
        <a href="#" class="btn btn-primary" data-node="button" data-type="primary">{{主按钮}}</a>
        <a href="#" class="btn btn-secondary" data-node="button" data-type="secondary">{{次按钮}}</a>
      </div>
    </div>
    <figure data-node="image" data-name="主视觉">
      <img src="https://placehold.co/560x400" alt="{{有意义的描述}}" style="width:100%;border-radius:var(--radius)">
    </figure>
  </div>
</section>
```

**feature-grid(卖点网格):** 注意每张卡是 component,卡内图标/标题/说明再各自标记。
```html
<section data-node="section" data-type="feature-grid" class="alt">
  <div class="wrap" data-node="container">
    <h2 class="center" data-node="text" data-type="heading">{{小标题}}</h2>
    <div class="grid" data-node="container" data-name="卡片网格" style="grid-template-columns:repeat(3,1fr);margin-top:48px">
      <div class="card" data-node="component" data-type="feature-card">
        <span data-node="icon" data-name="{{图标含义}}">⚡</span>
        <h3 data-node="text" data-type="heading">{{卖点标题}}</h3>
        <p data-node="text" style="margin-top:8px">{{卖点说明}}</p>
      </div>
      <!-- 重复 N 张卡 -->
    </div>
  </div>
</section>
```

**KPI 卡组(数据页 stats):**
```html
<section data-node="section" data-type="stats">
  <div class="wrap grid" data-node="container" style="grid-template-columns:repeat(4,1fr)">
    <div class="card" data-node="component" data-type="kpi-card" data-name="总访问量">
      <h3 data-node="text">总访问量</h3>
      <div data-node="text" data-type="metric" style="font-size:2rem;font-weight:700">128,430</div>
      <span data-node="text" data-type="delta">▲ 12.4%</span>
    </div>
    <!-- 重复若干 KPI 卡 -->
  </div>
</section>
```

**图表:** 外层标 `data-node="chart"`,内部 svg/柱子照旧。
```html
<div class="card" data-node="chart" data-type="line-chart" data-name="近 6 月用户增长">
  <h2 data-node="text" data-type="heading">近 6 月用户增长</h2>
  <svg role="img" aria-label="...">...</svg>
</div>
```

**pricing-table / cta-band / form / footer / nav / table** 同理:外层 `section`,内层用 `container` 框分组,可复用单元用 `component`,叶子按表格里的类别标 `icon/text/button/input/...`,并保持嵌套。

> 对未给完整模板的区块,沿用同一套:`:root` 变量 + 既有类(`.card/.btn/.grid/.muted`)+ 上面的标记与嵌套约定,保持视觉与结构一致。

## 第三步:自检(交付前)

- [ ] 完整 HTML(DOCTYPE/head/含 style/body),能存成 .html 直接打开。
- [ ] 每个有意义的节点都有 `data-node`,值在闭集内,没有自造类别。
- [ ] 包裹关系用嵌套表达:section→container→component→叶子,层级清晰,没拍平。
- [ ] 可复用单元标了 `component`,图标标 `icon`,图表标 `chart`,图片标 `image`。
- [ ] 颜色/圆角走 `:root` 变量;所有 img 有 alt;按钮/链接是 a 或 button;全页仅一个 h1。
- [ ] 文案具体可用,无占位词。

## 输出方式

直接给完整 HTML(代码块即可),不附长篇解释。关键假设用页面顶部一行 HTML 注释带过。
